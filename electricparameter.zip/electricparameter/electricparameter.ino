#include <PZEM004Tv30.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDR 0x3C

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// WiFi Credentials
const char* ssid = "DEVKIT_V1";
const char* password = "Oneman!524";

// Google Script URL
String GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbx3z5iegd82_MzvFy9GW6byL8Cc6Yh6s18JnmV7xUv-GEVj9EKGScC82P9qTfBzK-Ni4g/exec";

// Load Type
String loadType = "Fan";

// PZEM UART Pins
#define RXD2 16
#define TXD2 17

HardwareSerial pzemSerial(2);
PZEM004Tv30 pzem(pzemSerial, RXD2, TXD2);

// Web Server
AsyncWebServer server(80);

// Variables
float voltage, current, power, energy, frequency, pf;

// Simple Web Page
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<title>ESP32 Energy Monitor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
font-family:Arial;
text-align:center;
background:#f0f0f0;
}
.card{
background:white;
padding:20px;
margin:15px;
border-radius:10px;
font-size:25px;
}
</style>

<script>
setInterval(function(){

fetch('/data')
.then(response => response.json())
.then(data => {

document.getElementById("v").innerHTML = data.voltage + " V";
document.getElementById("c").innerHTML = data.current + " A";
document.getElementById("p").innerHTML = data.power + " W";
document.getElementById("e").innerHTML = data.energy + " kWh";
document.getElementById("f").innerHTML = data.frequency + " Hz";
document.getElementById("pf").innerHTML = data.pf;

});

},2000);
</script>

</head>

<body>

<h1>ESP32 Energy Monitor</h1>

<div class="card">Voltage: <span id="v">0</span></div>
<div class="card">Current: <span id="c">0</span></div>
<div class="card">Power: <span id="p">0</span></div>
<div class="card">Energy: <span id="e">0</span></div>
<div class="card">Frequency: <span id="f">0</span></div>
<div class="card">PF: <span id="pf">0</span></div>

</body>
</html>
)rawliteral";

void setup()
{
  Serial.begin(115200);

  // OLED Start
  Wire.begin(21,22);

  if(!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR))
  {
    Serial.println("OLED Failed");
    while(true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // PZEM UART Start
  pzemSerial.begin(9600, SERIAL_8N1, RXD2, TXD2);

  // WiFi Connect
  WiFi.begin(ssid, password);

  display.setCursor(0,0);
  display.println("Connecting WiFi...");
  display.display();

  while(WiFi.status()!=WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");

  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  // Web Page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
  {
    request->send_P(200, "text/html", index_html);
  });

  // JSON Data
  server.on("/data", HTTP_GET, [](AsyncWebServerRequest *request)
  {
    String json = "{";

    json += "\"voltage\":\"" + String(voltage,1) + "\",";
    json += "\"current\":\"" + String(current,2) + "\",";
    json += "\"power\":\"" + String(power,1) + "\",";
    json += "\"energy\":\"" + String(energy,3) + "\",";
    json += "\"frequency\":\"" + String(frequency,1) + "\",";
    json += "\"pf\":\"" + String(pf,2) + "\"";

    json += "}";

    request->send(200, "application/json", json);
  });

  server.begin();
}

void loop()
{
  // Read PZEM
  voltage = pzem.voltage();
  current = pzem.current();
  power = pzem.power();
  energy = pzem.energy();
  frequency = pzem.frequency();
  pf = pzem.pf();

  // Serial Monitor
  Serial.println("====== PZEM DATA ======");

  Serial.print("Voltage: ");
  Serial.println(voltage);

  Serial.print("Current: ");
  Serial.println(current);

  Serial.print("Power: ");
  Serial.println(power);

  Serial.print("Energy: ");
  Serial.println(energy);

  Serial.print("Frequency: ");
  Serial.println(frequency);

  Serial.print("PF: ");
  Serial.println(pf);

  Serial.println("=======================");

  // OLED Display
  display.clearDisplay();

  display.setCursor(0,0);

  display.print("V: ");
  display.println(voltage);

  display.print("I: ");
  display.println(current);

  display.print("P: ");
  display.println(power);

  display.print("PF:");
  display.println(pf);

  display.print("E: ");
  display.println(energy);

  display.print("F: ");
  display.println(frequency);

  display.display();

  // Google Sheets Upload
  if(WiFi.status()==WL_CONNECTED)
  {
    HTTPClient http;

    String url = GOOGLE_SCRIPT_URL +
                 "?voltage=" + String(voltage) +
                 "&current=" + String(current) +
                 "&power=" + String(power) +
                 "&pf=" + String(pf) +
                 "&frequency=" + String(frequency) +
                 "&energy=" + String(energy) +
                 "&load=" + loadType;

    http.begin(url);

    int httpCode = http.GET();

    Serial.print("HTTP Response: ");
    Serial.println(httpCode);

    http.end();
  }

  delay(5000);
}